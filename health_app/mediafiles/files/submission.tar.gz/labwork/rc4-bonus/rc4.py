import os


def rc4(key):
    j = 0
    sbox = list(range(256))
    for i in range(256):
        j = (j + sbox[i] + key[i % len(key)]) % 256
        (sbox[i], sbox[j]) = (sbox[j], sbox[i])

    i = j = 0

    key_stream = []
    for i in range(256):
        i = (i + 1) % 256
        j = (j + sbox[i]) % 256
        (sbox[i], sbox[j]) = (sbox[j], sbox[i])
        keybyte = sbox[(sbox[i] + sbox[j]) % 256]
        key_stream.append(keybyte.to_bytes(1, "little"))
    return key_stream



# key = bytes.fromhex("0102030405")
# key_stream = rc4(key)
# print(key_stream)

dict = {}
for i in range(0, 100000):
    key = os.urandom(16)
    key_stream = rc4(key)
    if key_stream[1] in dict:
        dict[key_stream[1]] += 1
    else:
        dict[key_stream[1]] = 1
print(dict)
print("0x00:",dict[b'\x00'])