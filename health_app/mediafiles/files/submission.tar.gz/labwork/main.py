#!/usr/bin/python3

import json
import sys

import requests
from labwork08 import handle_rsa_crt_fault_injection
from labwork07 import handle_timing_sidechannel
from labwork06 import handle_chi_square
from labwork01 import handle_ceasar, handle_histogram, handle_strcat
from labwork02 import (handle_block_cipher, handle_mul_gf2_128, handle_password_keyspace)
from labwork03 import handle_pkcs7_padding
from labwork04 import (handle_cbc_key_equals_iv, handle_gcm_block_to_poly, handle_gcm_mul_gf2_128)
from labwork05 import handle_rc4_fms
from labwork09 import handle_glasskey

if len(sys.argv) != 4:
	print("syntax: %s [API endpoint URI] [client ID] [assignment_name]" % (sys.argv[0]))
	sys.exit(1)

api_endpoint = sys.argv[1]
client_id = sys.argv[2]
assignment_name = sys.argv[3]



with requests.Session() as session:
    # GET request for assignments
    result = session.get(api_endpoint + "/assignment/" + client_id + "/" + assignment_name)
    assert (result.status_code == 200)
    assignment = result.json()


    # Handle assignments
    for testcase in assignment["testcases"]:
        match testcase["type"]:
            case "strcat":
                solution = handle_strcat(testcase["assignment"])
            case "histogram":
                solution = handle_histogram(testcase["assignment"])
            case "caesar_cipher":
                solution = handle_ceasar(testcase["assignment"])
            case "password_keyspace":
                solution = handle_password_keyspace(testcase["assignment"])
            case "mul_gf2_128":
                solution = handle_mul_gf2_128(testcase["assignment"])
            case "block_cipher":
                solution = handle_block_cipher(testcase["assignment"], api_endpoint)
            case "pkcs7_padding":
                solution = handle_pkcs7_padding(testcase["assignment"], api_endpoint)
            case "cbc_key_equals_iv":
                solution = handle_cbc_key_equals_iv(testcase["assignment"], api_endpoint)
            case "gcm_block_to_poly":
                solution = handle_gcm_block_to_poly(testcase["assignment"])
            case "gcm_mul_gf2_128":
                solution = handle_gcm_mul_gf2_128(testcase["assignment"])
            case "rc4_fms":
                solution = handle_rc4_fms(testcase["assignment"], testcase["tcid"], api_endpoint)
            case "chi_square":
                solution = handle_chi_square(testcase["assignment"])
            case "timing_sidechannel":
                solution = handle_timing_sidechannel(testcase["assignment"], api_endpoint)
            case "rsa_crt_fault_injection":
                solution = handle_rsa_crt_fault_injection(testcase["assignment"])
            case "glasskey":
                solution = handle_glasskey(testcase["assignment"])
            case other:
                print("Do not know how to handle type: %s" % (testcase["type"]))
                continue

        # POST request to submit solution for assignment
        result = session.post(api_endpoint + "/submission/" + testcase["tcid"],  headers = {
            "Content-Type": "application/json",
        }, data = json.dumps(solution))
        assert(result.status_code == 200)
        print(result.content)