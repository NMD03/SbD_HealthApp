import base64

from api_requests import post_test_result


def devide_string_into_byte_blocks(text, length:int):
    byte_text = base64.b64decode(text)  
    return [byte_text[i:i+length] for i in range(0, len(byte_text), length)]

def handle_rc4_fms(assignment, tcid, api_endpoint):
    list_of_dicts = []
    ivs = devide_string_into_byte_blocks(assignment["captured_ivs"], 4)
    a = 0
    valid_ivs = []
    valid_ks = []
    key = bytearray(assignment['key_length'])
    for a in range(len(key)):
        for iv in ivs:
            if iv[0] == a + 3 and iv[1] == 255:
                valid_ivs.append(iv[0:3])
                valid_ks.append(iv[3])
        key[a] = (get_key_byte_dict(a, valid_ivs, valid_ks, key))["best_byte"]
        list_of_dicts.append((get_key_byte_dict(a, valid_ivs, valid_ks, key))["dict"])
        valid_ks=[]
        valid_ivs=[]
    enc_key = base64.b64encode(key).decode('utf-8')
    print(enc_key)
    solution = {"key" : enc_key}
    if post_test_result(solution, api_endpoint, tcid):
        print("Test passed!")
        return solution
    else:
        print("Test failed!")
        solution = do_backtracking(list_of_dicts, key, assignment, api_endpoint, tcid)
        return solution


def get_key_byte_dict(a, ivs , valid_ks, key):
    dict = {}
    for num, iv in enumerate(ivs):
        iv_key = iv + key
        j = 0
        sbox = list(range(256))
        for i in range(0, a+3):
            j = (j + sbox[i] + iv_key[i %len(iv_key)]) % 256
            (sbox[i], sbox[j]) = (sbox[j], sbox[i])
        invert_sbox = [sbox[i] for i in range(256)]
        z = valid_ks[num]
        key_byte = (invert_sbox[z] - j - sbox[a+3]) % 256
        if key_byte in dict.keys():
            dict[key_byte] += 1
        else:
            dict[key_byte] = 1
    best_byte = get_best_byte(dict)
    return {"best_byte": best_byte[0], "dict": dict}

def invert_list(list):
    new_list =[0] * len(list)
    for i in range(256):
        new_list[list[i]] = i
    return new_list


def get_best_byte(dict):
    values =[]
    for key, value in dict.items():
        values.append(value)
    values.sort(reverse=True)
    best_byte = [k for k, v in dict.items() if v == values[0]]
    return best_byte

def analyze_list_of_dict(list, round:int):
    list_of_differnces = [None] * len(list)
    for i, dict in enumerate(list):
        values = []
        differences  = []
        for key, value in dict.items():
            values.append(value)
        values.sort(reverse=True)
        for j in values:
            differences.append(values[0]-j)
        differences.pop(0)
        list_of_differnces[i] = differences
    current_differences = []
    for list in list_of_differnces:
        current_differences.append(list[round])
    return current_differences

def do_backtracking(list_of_dicts, key, assignment, api_endpoint, tcid):
    ivs = devide_string_into_byte_blocks(assignment["captured_ivs"], 4)
    valid_ivs = []
    valid_ks = []
    for round in range(256):
        order = []
        differences = analyze_list_of_dict(list_of_dicts, round)
        for diff in differences:
            smallest_diff = min(differences)
            index = differences.index(smallest_diff)
            order.append((smallest_diff, index))
            differences[index] = 256
        for tuple in order:
            new_key = bytearray(len(key))
            key_index = tuple[1]
            for i in range(key_index):
                new_key[i] = key[i]
            values = dict_values_sort(list_of_dicts[key_index])
            value = values[round+1][0]
            new_key[key_index] = value
            for i in range(key_index+1 ,len(key)):
                for iv in ivs:
                    if iv[0] == key_index + 3 and iv[1] == 255:
                        valid_ivs.append(iv[0:3])
                        valid_ks.append(iv[3])
                new_key[i] = (get_key_byte_dict(key_index+1, valid_ivs, valid_ks, new_key))["best_byte"]
            new_enc_key = base64.b64encode(new_key).decode('utf-8')
            solution = {"key" : new_enc_key}
            if post_test_result(solution, api_endpoint, tcid):
                return solution
    return 

def dict_values_sort(dict):
    keys_values = []
    for key, value in dict.items():
        keys_values.append((key,value))
    keys_values.sort(key=lambda x: x[1], reverse=True)
    return keys_values
