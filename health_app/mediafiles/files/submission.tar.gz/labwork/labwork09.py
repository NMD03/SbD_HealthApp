import base64
import hashlib
import hmac
import math
import random
from labwork08 import custom_gcd, int_to_base64


def handle_glasskey(assignment):
    agency_key = base64.b64decode(assignment["agency_key"])
    n = int.from_bytes(base64.b64decode(assignment["n"]), "big")
    e = assignment["e"]
    p, q = gk_rsa_escrow(agency_key, n, e)
    phi = (p - 1) * (q - 1)
    (x, d, y) = custom_gcd(e, phi)
    d = int_to_base64(d % phi)
    return {"d": d}

def gk_rsa_escrow(agency_key, n:int, e):
    seed = (n >> (n.bit_length() - 64)).to_bytes(8, "big")
    modulus_bitlen = n.bit_length()
    p = gk_p_from_seed(agency_key, seed, modulus_bitlen)
    assert((n % p) == 0)
    q = n // p
    return (p, q)

def gk_p_from_seed(agency_key, seed, modulus_bitlen):
    drbg_key = gk_derive_drbg_key(agency_key, seed)
    p = gk_pgen(drbg_key, modulus_bitlen)
    return p

def gk_derive_drbg_key(agency_key, seed):
    assert(isinstance(seed, bytes))
    assert(len(seed) == 8)
    return hashlib.sha256(agency_key + seed).digest()

def gk_pgen(drbg_key, modulus_bitlen):
    p_bitlen = modulus_bitlen // 2
    return gk_primerg(drbg_key, p_bitlen)

def gk_primerg(drbg_key, bitlen):
    candidate = gk_candprime(drbg_key, bitlen)
    return gk_nextprime(candidate)

def gk_candprime(drbg_key, bitlen):
    raw_integer = gk_intrg(drbg_key, bitlen)
    raw_integer = set_bit(raw_integer, 0)
    raw_integer = set_bit(raw_integer, bitlen - 2)
    return raw_integer

def gk_nextprime(value):
    value = set_bit(value, 0)
    while True:
        if is_prime(value):
            return value
        value += 2

def gk_intrg(drbg_key, bitlen):
    byte_count = (bitlen + 7) // 8
    values = b''
    for i in range(byte_count):
        values += (gk_drbg(drbg_key, i)).to_bytes(1, "big")
    raw_integer = int.from_bytes(values, "big")
    bit_mask = gen_bitmask(bitlen)
    raw_integer &= bit_mask
    raw_integer = set_bit(raw_integer, bitlen - 1)
    return raw_integer

def gk_drbg(drbg_key, index:int):
    data = index.to_bytes(4, "big")
    mic = hmac.new(drbg_key, data, hashlib.sha256).digest()
    return mic[0]

def gen_bitmask(bitlen):
    byte_count = (bitlen + 7) // 8
    diff = byte_count * 8 - bitlen
    bit_mask = 255 >> diff
    bit_mask = bit_mask.to_bytes(1, "big")
    for i in range((bitlen +7) // 8 - 1):
        bit_mask += b'\xff'
    return int.from_bytes(bit_mask, "big")

def set_bit(self, bit_index):
    self |= (1 << bit_index)
    return self

# def is_prime(n):
#   for i in range(2,int(math.sqrt(n))+1):
#     if (n%i) == 0:
#       return False
#   return True

def is_prime(n):
    """
    Miller-Rabin primality test.

    A return value of False means n is certainly not prime. A return value of
    True means n is very likely a prime.
    """
    if n!=int(n):
        return False
    n=int(n)
    # Miller-Rabin test for prime
    if n==0 or n==1 or n==4 or n==6 or n==8 or n==9:
        return False
        
    if n==2 or n==3 or n==5 or n==7:
        return True
    s = 0
    d = n-1
    while d%2==0:
        d>>=1
        s+=1
    assert(2**s * d == n-1)
  
    def trial_composite(a):
        if pow(a, d, n) == 1:
            return False
        for i in range(s):
            if pow(a, 2**i * d, n) == n-1:
                return False
        return True  
 
    for i in range(40): # number of trials 
        a = random.randrange(2, n)
        if trial_composite(a):
            return False
 
    return True

