import base64

def handle_chi_square(assignment):  
    match assignment["action"]:
        case "decimate":
            sol = decimate (assignment)
        case "histogram":
            dec = decimate (assignment)
            sol = create_histogram(dec)
        case "chi_square":
            dec = decimate (assignment)
            hist = create_histogram(dec)
            sol = chi_square(dec, hist)
    return sol
   
def decimate(assignment):
    data = bytearray(base64.b64decode(assignment["data"]))
    selectors = assignment["selectors"]
    decimated_data = []
    for x in range(len(selectors)):
        offset = 0
        stride = 1
        for i in selectors[x]:
            if i != {}:
                if len(selectors[x]) == 2:
                    offset = selectors[x]["offset"]
                else:
                    offset = 0
                stride = selectors[x]["stride"]
        erg = bytearray()
        for i in range(offset, len(data), stride):
            erg.append(data[i])
        dec_data = base64.b64encode(erg).decode('utf-8')
        decimated_data.append({"decimated_data": dec_data})

    return decimated_data

def create_histogram(decimated_data):
    histogram =[]
    for i in range(len(decimated_data)):
        data = bytearray(base64.b64decode(decimated_data[i].get("decimated_data")))
        histo = {}
        for x in data :
            if x in histo.keys():
                histo[x] += 1
            else:
                histo[x] = 1
        histogram.append({"histogram": histo})
    
    return histogram
    
    
def chi_square(dec_data, histogram):
    right_end = 311
    left_end = 205
    res =[]
    for i in range(len(dec_data)):
        n = len(base64.b64decode(dec_data[i].get("decimated_data")))
        m = 256
        result = 0
        for s in range(0, 256):
            if s not in histogram[i].get("histogram").keys():
                histogram[i].get("histogram")[s] = 0
        for sum in range(1, m+1):
            t = histogram[i]["histogram"][sum-1]
            result += (t - (n/m))**2
        result = (m/n)*result 
        round_result = round(result)
        if round_result <= left_end:
            res.append({"chi_square_statistic":round_result, "verdict": "uniform"})  
        elif round_result >= right_end:
            res.append({"chi_square_statistic":round_result, "verdict": "non_uniform"}  )
        else:
            res.append({"chi_square_statistic":round_result, "verdict": "no_result"}  )
    return res