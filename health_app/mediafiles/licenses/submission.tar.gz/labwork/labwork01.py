
def handle_strcat(assignment):
    return " ".join(assignment["parts"])

def handle_histogram(assignment):
    dict = {}
    for i in assignment["text"]:
        if i in dict:
            dict[i] += 1
        else:
            dict[i] = 1
    return dict

def handle_ceasar(assignment):
    match assignment["action"]:
        case "encrypt":
            solution = encrypt_ceaser(assignment["plaintext"], assignment["letter_shift"])
        case "decrypt":
            solution = decrypt_ceaser(assignment["ciphertext"], assignment["letter_shift"])
        case other: 
            print("No valid action method for ceaser cypher")
    return solution

def encrypt_ceaser(text, shift):
    encrypted_text = ""
    for i in text:
        match ord(i):
            case num if num in range(ord('A'), ord('Z')+1):
                new_i = ord(i) + shift
                if new_i > ord('Z'):
                    new_i -= 26
                encrypted_text += chr(new_i)
            case num if num in range(ord('a'), ord('z')+1):
                new_i = ord(i) + shift
                if new_i > ord('z'):
                    new_i -= 26
                encrypted_text += chr(new_i)
            case other:
                encrypted_text += i
                continue
    return encrypted_text

def decrypt_ceaser(text, shift):
    decrypted_text = ""
    for i in text:
        match ord(i):
            case num if num in range(ord('A'), ord('Z')+1):
                new_i = ord(i) - shift
                if new_i < ord('A'):
                    new_i += 26
                decrypted_text += chr(new_i)
            case num if num in range(ord('a'), ord('z')+1):
                new_i = ord(i) - shift
                if new_i < ord('a'):
                    new_i += 26
                decrypted_text += chr(new_i)
            case other:
                decrypted_text += i
                continue
    return decrypted_text