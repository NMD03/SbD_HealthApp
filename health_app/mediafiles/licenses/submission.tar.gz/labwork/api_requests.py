import json
import requests

session = requests.Session()

def post_oracle(oracle_name, operation, key, text, api_endpoint):
    if operation == "encrypt":
        message = {"operation" : operation, "key" : key, "plaintext" : text}
        result = session.post(api_endpoint + "oracle/" + oracle_name,  headers = {
		"Content-Type": "application/json",
	    }, data = json.dumps(message))
        encrypted_text = result.json()
        return encrypted_text["ciphertext"]
    elif operation == "decrypt":
        message = {"operation" : operation, "key" : key, "ciphertext" : text}
        result = session.post(api_endpoint + "oracle/" + oracle_name,  headers = {
		"Content-Type": "application/json",
	    }, data = json.dumps(message))
        decrypted_text = result.json()
        return decrypted_text["plaintext"]
    else:
        print("No valid operation for Oracle!")
        return
  
def post_padding_oracle(keyname, iv, ciphertext, api_endpoint):
    message = {"keyname" : keyname, "iv" : iv, "ciphertext" : ciphertext}
    result = session.post(api_endpoint + "oracle/pkcs7_padding" ,  headers = {
	"Content-Type": "application/json",
	}, data = json.dumps(message))
    info = result.json()
    return info["status"]
    
def post_key_equals_iv_oracle(keyname, ciphertext, api_endpoint):
    message = {"keyname" : keyname, "ciphertext" : ciphertext}
    result = session.post(api_endpoint + "oracle/cbc_key_equals_iv" ,  headers = {
	"Content-Type": "application/json",
	}, data = json.dumps(message))
    decrypt = result.json()
    return decrypt["plaintext"]

def post_test_result(solution, api_endpoint, tcid):
    result = session.post(api_endpoint + "/submission/" + tcid,  headers = {
		"Content-Type": "application/json",
	}, data = json.dumps(solution))
    content = result.content
    obj = json.loads(content)
    if obj["status"] == "pass":
        return True
    else:
        return False

def post_timing_sidechannel(user, password, api_endpoint):
    result = session.post(api_endpoint + "oracle/timing_sidechannel",  headers = {
        "Content-Type": "application/json",
    }, data = json.dumps({"user" : user, "password" : password}))
    return json.loads(result.content)