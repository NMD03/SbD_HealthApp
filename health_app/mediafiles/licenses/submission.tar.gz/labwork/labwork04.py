import base64
from api_requests import post_key_equals_iv_oracle
from labwork02 import devide_blocks_16_bytes
from labwork02 import handle_mul_gf2_128
from labwork02 import xor_base64

def handle_cbc_key_equals_iv(assignment, api_endpoint):
    blocks = devide_blocks_16_bytes(assignment["valid_ciphertext"])
    blocks.append(blocks[-2])
    blocks.append(blocks[-2])
    blocks[1] = (0).to_bytes(16, "little")
    blocks[2] = blocks[0]
    attack_text = b''
    for block in blocks:
        attack_text += block
    plaintext = post_key_equals_iv_oracle(assignment["keyname"], base64.b64encode(attack_text).decode("utf-8") ,api_endpoint)
    plaintext_blocks = devide_blocks_16_bytes(plaintext)
    c0 = xor_base64(plaintext_blocks[0], plaintext_blocks[2], 16)
    return {"key": c0}

def handle_gcm_block_to_poly(assignment):
    block = base64.b64decode(assignment["block"])
    byte_array = list(block)
    solution = []
    for i, byte in enumerate(byte_array):
        for j in range(7, -1, -1):
            if byte_array[i] - (2**j) >= 0:
                byte_array[i] -= 2**j
                solution.append(8*i+7-j)
    return {"coefficients": solution}

def coefficients_to_int(dict):
    int_value  = 0
    for i in dict["coefficients"]:
        int_value += 2**i
    return int_value

def handle_gcm_mul_gf2_128(assignment):
    a = assignment["a"]
    b = assignment["b"]
    convert_b = handle_gcm_block_to_poly({"block" : b})
    b = convert_b["coefficients"]
    convert_a = handle_gcm_block_to_poly({"block" : a})
    a = base64.b64encode((coefficients_to_int(convert_a)).to_bytes(16, "little")).decode("utf-8")
    solution = "AAAAAAAAAAAAAAAAAAAAAA=="
    for i in range(0, 128):
        if i in b:
            solution = xor_base64(base64.b64decode(solution), base64.b64decode(a), 16)
        times_alpha = handle_mul_gf2_128({"block": a})
        a = times_alpha["block_times_alpha"]
    convert_solution = handle_gcm_block_to_poly({"block": solution})
    solution = base64.b64encode((coefficients_to_int(convert_solution)).to_bytes(16, "little")).decode("utf-8")
    return {"a*b" : solution}

