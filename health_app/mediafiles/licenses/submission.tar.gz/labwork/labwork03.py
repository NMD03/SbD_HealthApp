import base64
from api_requests import post_padding_oracle
from labwork02 import devide_blocks_16_bytes
from labwork02 import xor_base64


def handle_pkcs7_padding(assignment, api_endpoint):
    blocks = devide_blocks_16_bytes(assignment["ciphertext"])
    solution = b''
    iv = base64.b64decode(assignment["iv"])
    for block in blocks:
        cracked_block = crack_encryption_with_padding(assignment, api_endpoint, block)
        solution = solution + base64.b64decode(xor_base64(cracked_block, iv, len(iv)))
        iv = block
    plaintext = remove_padding(bytearray(solution))    
    return {"plaintext" : plaintext}

def crack_encryption_with_padding(assignment, api_endpoint, block):
    q = bytearray(16)
    solution = bytearray(16)
    for byte in range(len(block)-1, -1, -1):
        for i in range(0, 256):
            q[byte] = i
            status = post_padding_oracle(assignment["keyname"], (base64.b64encode(q)).decode("utf-8"), base64.b64encode(block).decode("utf-8"), api_endpoint)
            match status:
                case "padding_invalid":
                    continue
                case "padding_correct":
                    if byte == 15:
                        if preclude_false_positive(assignment, api_endpoint, q, block):
                            plain_byte = base64.b64decode(xor_base64(q[byte].to_bytes(1, "little"), (16-byte).to_bytes(1, "little"), 1))
                            solution[byte] = int.from_bytes(plain_byte, "little")
                            q = get_q_to_force_padding_byte(q, solution, 16-byte)
                            break
                        else:
                            continue   
                    else:
                        plain_byte = base64.b64decode(xor_base64(q[byte].to_bytes(1, "little"), (16-byte).to_bytes(1, "little"), 1))
                        solution[byte] = int.from_bytes(plain_byte, "little")
                        if byte != 0:
                            q = get_q_to_force_padding_byte(q, solution, 16-byte)
                        break        
                case other:
                    print("No valid status while testing correct padding!")
    return bytes(solution)

def preclude_false_positive(assignment, api_endpoint, q, block):
    q[14] = 255
    status = post_padding_oracle(assignment["keyname"], (base64.b64encode(q)).decode("utf-8"), base64.b64encode(block).decode("utf-8"), api_endpoint)
    if status == "padding_correct":
        return True
    else:
        return False

def get_q_to_force_padding_byte(q:bytearray, known_bytes:bytearray, num_of_known_bytes:int):
    for i in range(1, num_of_known_bytes+1):
        q[16-i] = int.from_bytes(base64.b64decode(xor_base64(known_bytes[16-i].to_bytes(1, "little") , (num_of_known_bytes+1).to_bytes(1, "little"), 1)), "little")
    return q

def remove_padding(bytes:bytearray):
    padding = bytes[-1]
    for i in range(0, padding):
        bytes.pop()
    text = base64.b64encode(bytes).decode("utf-8")
    return text
