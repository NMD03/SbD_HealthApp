import base64
import hashlib
import math
import sys

def handle_rsa_crt_fault_injection(assignment):
    sys.setrecursionlimit(10000)
    msg = assignment["msg"]
    sig1 = int.from_bytes(base64.b64decode(assignment["sigs"][0]), "big")
    sig2 = int.from_bytes(base64.b64decode(assignment["sigs"][1]), "big")
    e = int.from_bytes(base64.b64decode(assignment["pubkey"]["e"]), "big")
    n = int.from_bytes(base64.b64decode(assignment["pubkey"]["n"]), "big")

    if test_signature(msg, sig1, e, n):
        sig = sig1
        sig_corrupt = sig2
    else:
        sig = sig2
        sig_corrupt = sig1

    p = math.gcd(pow(sig_corrupt, e, n) - pow(sig, e, n), n)
    q = n // p
    if p > q:
        p, q = q, p
    phi = (p - 1) * (q - 1)
    (x, d, y) = custom_gcd(e, phi)
    d = d % phi
    d = int_to_base64(d)
    p = int_to_base64(p)
    q = int_to_base64(q)
    return {"d": d, "p": p, "q": q}

def test_signature(msg, sig, e, n):
    hash = hashlib.md5(base64.b64decode(msg)).digest()
    m = (pow(sig, e, n))
    if hash in m.to_bytes((m.bit_length() + 7) // 8, "big"):
        return True

def custom_gcd(a, b):
    if b == 0:
        return (a, 1, 0)
    (d_, x_, y_) = custom_gcd(b, a % b)
    (d, x, y) = (d_, y_, x_ - (a // b) * y_)
    return (d, x, y)

def int_to_base64(i):
    return base64.b64encode(i.to_bytes((i.bit_length() + 7) // 8, "big")).decode("utf-8")