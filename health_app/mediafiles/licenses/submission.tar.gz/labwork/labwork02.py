import base64
from itertools import product
from api_requests import post_oracle

def handle_password_keyspace(assignment):
    alphabet = []
    for i in assignment["alphabet"]:
        alphabet.append(i)
    alphabet_stats = analyze_alphabet(alphabet)
    passwords = list(product(alphabet, repeat=assignment["length"]))
    for restrictions in assignment["restrictions"]:
        match restrictions:
            case "at_least_one_special_char": 
                passwords = get_vaild_at_least_one_passwords(passwords, alphabet_stats, "special")
            case "at_least_one_uppercase_char":
                passwords = get_vaild_at_least_one_passwords(passwords, alphabet_stats, "upper_case")
            case "at_least_one_lowercase_char":
                passwords = get_vaild_at_least_one_passwords(passwords, alphabet_stats, "lower_case")
            case "at_least_one_digit":
                passwords = get_vaild_at_least_one_passwords(passwords, alphabet_stats, "digits")
            case "no_consecutive_same_char":
                passwords = get_valid_without_consumption_passwords(passwords, assignment["length"])
            case "special_char_not_last_place": 
                passwords = get_valid_last_place_passwords(passwords, assignment["length"], alphabet_stats["special"])    
            case other:
                print("No valid restriction for password!")
                continue
    return {"count" : len(passwords)}

def analyze_alphabet(alphabet):
    upper_case = []
    lower_case = []
    digits = []
    special = []
    for i in alphabet:
        match ord(i):
            case num if num in range(ord("A"), ord("Z")+1):
                upper_case.append(i)
            case num if num in range(ord("a"), ord("z")+1):
                lower_case.append(i)
            case num if num in range(ord("0"), ord("9")+1):
                digits.append(i)
            case other:
                special.append(i)
    return {"upper_case" : upper_case, "lower_case" : lower_case, "digits" : digits, "special" : special}

def get_vaild_at_least_one_passwords(passwords, alphabet_stats, type):
    valid_passwords = []
    for password in passwords:
        for char in alphabet_stats[type]:
            if char in password:
                valid_passwords.append(password)
                break
    return valid_passwords

def get_valid_without_consumption_passwords(passwords, length):
    valid_passwords = []
    for password in passwords:
        repetition = 0
        for i in range(0, length-1):
            if password[i] == password[i+1]:
                repetition += 1
        if repetition == 0:
            valid_passwords.append(password)
    return valid_passwords

def get_valid_last_place_passwords(passwords, length, special):
    valid_passwords = []
    for password in passwords:
        if password[length-1] in special:
            continue
        valid_passwords.append(password)
    return valid_passwords

def handle_mul_gf2_128(assignment): 
    block = int.from_bytes(base64.b64decode(assignment["block"]), "little")
    if block < 2 ** 127:
        new_block = block << 1
    else:
        new_block = block << 1
        irreducible_polynomial = 2**128 + 2**7 + 2**2 + 2 + 1
        new_block = new_block ^ irreducible_polynomial
    new_byte_block = new_block.to_bytes(16, "little")
    return {"block_times_alpha": (base64.b64encode(new_byte_block)).decode("utf-8")}

def handle_block_cipher(assignment, api_endpoint):
    match assignment["opmode"]:
        case "cbc":
            if assignment["operation"] == "encrypt":
                return cbc("encrypt", assignment["key"], assignment["iv"], assignment["plaintext"], api_endpoint)
            elif assignment["operation"] == "decrypt":
                return cbc("decrypt", assignment["key"], assignment["iv"], assignment["ciphertext"], api_endpoint)
            else:
                print("No valid operation for CBC!")
        case "ctr":
            if assignment["operation"] == "encrypt":
                return ctr("encrypt", assignment["key"], assignment["nonce"], assignment["plaintext"], api_endpoint) 
            elif assignment["operation"] == "decrypt":
                return ctr("decrypt", assignment["key"], assignment["nonce"], assignment["ciphertext"], api_endpoint)
            else:
                print("No valid operation for CTR!")
        case "xex":
            if assignment["operation"] == "encrypt":
                return xex(assignment["key"], "encrypt", assignment["plaintext"], assignment["tweak"], api_endpoint)
            elif assignment["operation"] == "decrypt":
                return xex(assignment["key"], "decrypt", assignment["ciphertext"], assignment["tweak"], api_endpoint)
            else:
                print("No valid operation for XEX!")
        case other:
            print("No valid mode!")
            return

def cbc(operation, key, iv, text, api_endpoint):
    solution = b''
    blocks = devide_blocks_16_bytes(text)
    if operation == "encrypt":
        for block in blocks:
            xor = xor_base64(block, base64.b64decode(iv), len(block))  
            encrypted_text = post_oracle("block_cipher", operation, key, xor, api_endpoint) 
            iv = encrypted_text
            solution += base64.b64decode(encrypted_text)
        solution = (base64.b64encode(solution)).decode("utf-8")
        return {"ciphertext": solution}
    else:
        for block in blocks:  
            encrypted_text = post_oracle("block_cipher", operation, key, (base64.b64encode(block)).decode("utf-8"), api_endpoint) 
            xor = xor_base64(base64.b64decode(encrypted_text), base64.b64decode(iv), len(block))
            iv = base64.b64encode(block)
            solution += base64.b64decode(xor)
        solution = (base64.b64encode(solution)).decode("utf-8")
        return {"plaintext": solution}
    
def ctr(operation, key, nonce, text, api_endpoint):
    solution = b''
    blocks = devide_blocks_16_bytes(text)
    counter = base64.b64decode("AAAAAA==")
    for block in blocks:
        nonce_concat_ctr = base64.b64decode(nonce) + counter
        encrypted_text = post_oracle("block_cipher", "encrypt", key, (base64.b64encode(nonce_concat_ctr)).decode("utf-8"), api_endpoint)
        xor = xor_base64(base64.b64decode(encrypted_text), block, len(block))
        solution += base64.b64decode(xor)
        counter = (int.from_bytes(counter, "big") + 1).to_bytes(4, "big")
    solution = (base64.b64encode(solution)).decode("utf-8")
    if operation == "encrypt":
        return {"ciphertext" : solution}
    else:
        return {"plaintext" : solution}   

def xex(key, operation, text, tweak, api_endpoint):
    solution = b''
    key = devide_blocks_16_bytes(key)
    first_key = (base64.b64encode(key[0])).decode("utf-8")
    second_key = (base64.b64encode(key[1])).decode("utf-8")
    first_encrypt = post_oracle("block_cipher", "encrypt", second_key, tweak, api_endpoint)
    blocks = devide_blocks_16_bytes(text)
    for block in blocks:
        first_xor = xor_base64(base64.b64decode(first_encrypt), block, len(block))
        second_encrypt = post_oracle("block_cipher", operation, first_key, first_xor, api_endpoint)
        second_xor = xor_base64(base64.b64decode(second_encrypt), base64.b64decode(first_encrypt), len(block))
        solution += base64.b64decode(second_xor)
        times_alpha = handle_mul_gf2_128({"block" : first_encrypt})
        first_encrypt = times_alpha["block_times_alpha"]
    solution = (base64.b64encode(solution)).decode("utf-8")
    if operation == "encrypt":
        return {"ciphertext" : solution}
    else: 
        return {"plaintext" : solution}
    
def xor_base64(block01, block02, block_length):
    """XOR of two blocks.

    Args:
        block01 (bytes): The first operand
        block02 (bytes): The second operand
        block_length (int): length of the blocks

    Returns:
        str: The result of the XOR bas64 encoded
    """
    xor = int.from_bytes(block01, "little") ^ int.from_bytes(block02, "little")
    return  (base64.b64encode(xor.to_bytes(block_length, "little"))).decode("utf-8") 

def devide_blocks_16_bytes(text):
    """Divides text into 16 Byte blocks.

    Args:
        text (str): text base64 encoded

    Returns:
        bytes: list with 16 byte blocks
    """
    byte_text = base64.b64decode(text)  
    return [byte_text[i:i+16] for i in range(0, len(byte_text), 16)]

